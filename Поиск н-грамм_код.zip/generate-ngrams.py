# из файла с предложениями (одна строка - одно предложение) создаем несколько файлов с 2-,3-,4-gramm

import re
import json
from nltk.util import ngrams


fname = "chilllinn.json.txt"
f = open(fname)

# очищаем файл путем его создания
fw2 = open("ng2-" + fname, "w")
fw2.close()
# открываем на дозапись
fw2 = open("ng2-" + fname, "a")
fw2.write("id,ngram")

fw3 = open("ng3-" + fname, "w")
fw3.close()
fw3 = open("ng3-" + fname, "a")
fw3.write("id,ngram")

fw4 = open("ng4-"+fname, "w")
fw4.close()
fw4 = open("ng4-"+fname, "a")
fw4.write("id,ngram")

i2 = 0
i3 = 0
i4 = 0

for sentence in f:
    sentence = sentence.lower().rstrip()
    sentence = re.sub(r'&lt;', '<', sentence)
    sentence = re.sub(r'&gt;', '>', sentence)
    sentence = re.sub(r'https://t.co/(.*)', '', sentence)
    sentence = re.sub(r'[,.;•?!#_@…❤️💙😅🔥😂🌼💫ㅋㅜ‍ㅠㄱ‼~●-]+', ' ', sentence)
    sentence = re.sub(r'[^\w\s]+|[\d]+', ' ', sentence)
    sentence = re.sub(r'[a-zA-Z]', ' ', sentence)
    sentence = re.sub(r' +', ' ', sentence)
    tokens = [token for token in sentence.split() if token != ""]
    print(tokens)

    # токенизатор нлтк не устанавливался, потом пробовался Спейси, но он оказался слишком долгим, а эта вещь выше^
    # и быстрая, и результат такой же, как у Спейси...

    output = list(ngrams(tokens, 2))
    for row in output:
        i2 += 1
        fw2.write("\n" + str(i2) + "," + " ".join(row))
        # fw2.write(json.dumps(output, ensure_ascii=False)+"\n")

    output = list(ngrams(tokens, 3))
    for row in output:
        i3 += 1
        fw3.write("\n" + str(i3) + "," + " ".join(row))

    output = list(ngrams(tokens, 4))
    for row in output:
        i4 += 1
        fw4.write("\n" + str(i4) + "," + " ".join(row))

f.close()
fw2.close()
fw3.close()
fw4.close()
