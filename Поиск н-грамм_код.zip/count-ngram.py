import pandas as pd

fname = 'ng2-chilllinn.json.txt'
df = pd.read_csv(fname)
df.groupby('ngram').agg(
        ngram_count=("id", "size")
    ).reset_index().sort_values(
        by=['ngram_count'], ascending=False
    ).head(100).to_csv(
        fname + '.csv', columns=['ngram', 'ngram_count'], index=False
    )


fname = 'ng3-chilllinn.json.txt'
df = pd.read_csv(fname)
df.groupby('ngram').agg(
        ngram_count=("id", "size")
    ).reset_index().sort_values(
        by=['ngram_count'], ascending=False
    ).head(100).to_csv(
        fname + '.csv', columns=['ngram', 'ngram_count'], index=False
    )


fname = 'ng4-chilllinn.json.txt'
df = pd.read_csv(fname)
df.groupby('ngram').agg(
        ngram_count=("id", "size")
    ).reset_index().sort_values(
        by=['ngram_count'], ascending=False
    ).head(100).to_csv(
        fname + '.csv', columns=['ngram', 'ngram_count'], index=False
    )
