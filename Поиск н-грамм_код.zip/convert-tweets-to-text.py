import sys
import json

if len(sys.argv) < 2:
    print("Error arguments. Please select file name.")
    exit()

fname = sys.argv[1]  # как дополнительный вариант, но можно и без него обойтись


# Открываем JSON
f = open(fname)

fw = open(fname+'.txt', "w")
fw.close()

fw = open(fname+'.txt', "a")  # append mode

for str in f:
    data = json.loads(str)
    fw.write(data['tweet'])
    fw.write("\n")

# закрываем файлы
f.close()
fw.close()
